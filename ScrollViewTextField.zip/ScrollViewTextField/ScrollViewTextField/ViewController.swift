//
//  ViewController.swift
//  ScrollViewTextField
//
//  Created by jabeed on 27/11/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,UITextFieldDelegate{
    @IBOutlet weak var textfield1: UITextField!
    
    @IBOutlet weak var textfield2: UITextField!
    
    @IBOutlet weak var textfield7: UITextField!
    @IBOutlet weak var textfield6: UITextField!
    @IBOutlet weak var textfield5: UITextField!
    
    @IBOutlet weak var textfield8: UITextField!
    @IBOutlet weak var textfield3: UITextField!
    
    @IBOutlet weak var textfield9: UITextField!
    @IBOutlet weak var textfield4: UITextField!
    
    
    @IBOutlet weak var textfield10: UITextField!
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyborad()
        textfield1.delegate = self
        textfield2.delegate = self
        textfield3.delegate = self
        textfield4.delegate = self
        textfield5.delegate = self
        textfield6.delegate = self
        textfield7.delegate = self
        textfield8.delegate = self
        textfield9.delegate = self
        textfield10.delegate = self

        
        // Do any additional setup after loading the view.
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }


}

extension UIViewController{
    func hideKeyborad() {
        let tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyborad))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyborad() {
        view.endEditing(true)
    }
}
